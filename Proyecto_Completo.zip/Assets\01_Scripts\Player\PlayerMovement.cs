using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float rotationSpeed = 250f;
    [SerializeField] private float joystickDeadZone = 0.1f;
    
    [Header("Components")]
    private Animator animator;
    
    void Start()
    {
        // Get animator component
        animator = GetComponent<Animator>();
    }
    
    void Update()
    {
        // Get joystick/keyboard input
        float VelX = Input.GetAxis("Horizontal");
        float VelY = Input.GetAxis("Vertical");
        
        // Apply dead zone
        if (Mathf.Abs(VelX) < joystickDeadZone)
            VelX = 0f;
        if (Mathf.Abs(VelY) < joystickDeadZone)
            VelY = 0f;
        
        // Rotate player with horizontal input
        if (Mathf.Abs(VelX) > 0.1f)
        {
            transform.Rotate(0, VelX * Time.deltaTime * rotationSpeed, 0);
        }
        
        // Move player with vertical input
        if (Mathf.Abs(VelY) > 0.1f)
        {
            transform.Translate(0, 0, VelY * Time.deltaTime * moveSpeed);
        }
        
        // Update animator
        if (animator != null)
        {
            animator.SetFloat("VelX", VelX);
            animator.SetFloat("VelY", VelY);
        }
    }
}
